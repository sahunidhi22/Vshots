# Vshots - Vertical Video Streaming App

<!-- Use this file to provide workspace-specific custom instructions to Copilot. For more details, visit https://code.visualstudio.com/docs/copilot/copilot-customization#_use-a-githubcopilotinstructionsmd-file -->

This is a React Native mobile application called "Vshots" - a vertical video streaming platform similar to TikTok, Instagram Reels, or Dramabox.

## Project Structure
- Built with Expo and React Native
- Uses Expo Router for navigation
- TypeScript for type safety
- Video playback with expo-av

## Key Features
- Vertical video streaming and playback
- Category-based content filtering (What's New, Favourite, Genre)
- Top categories showcase (Top 1, Top 2, Top 3)
- Search and discovery functionality  
- Full-screen video player with controls
- Genre-based filtering
- Modern dark theme UI

## Design Guidelines
- Dark theme with black (#000) background
- Purple (#8B5CF6) brand color for buttons and accents  
- Orange (#FF6B35) for active states
- White text with gray (#999) secondary text
- Vertical video orientation priority
- Mobile-first responsive design

## Development Notes
- Use proper TypeScript types for all components
- Follow React Native best practices
- Implement gesture-based navigation for video player
- Use FlatList for performance with large video lists
- Optimize images and video loading
- Handle video playback states properly
